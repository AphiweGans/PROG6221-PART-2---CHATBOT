using System.Windows;

namespace CyberAware.UI.Wpf
{
    public partial class NameEntryWindow : Window
    {
        public string EnteredName { get; private set; } = string.Empty;
        public NameEntryWindow()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void BtnOk_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text)) return;
            EnteredName = txtName.Text.Trim();

            // Persist initial memory so backend knows current user
            try
            {
                var handler = new CyberAware.ResponseHandler();
                handler.SaveMemory(new CyberAware.ResponseHandler.UserMemory { UserName = EnteredName, FavoriteTopic = null });
            }
            catch { }

            this.DialogResult = true;
            this.Close();
        }
    }
}