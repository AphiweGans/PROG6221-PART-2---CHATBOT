using System.Windows;
using System.Windows.Controls;
using CyberAware;

namespace CyberAware.UI.Wpf
{
    public partial class MainWindow : Window
    {
        private readonly ChatBot _chatBot = new ChatBot();
        private readonly string userName;
        private int msgCount = 0;
        private int topicCount = 0;

        public MainWindow(string userName)
        {
            InitializeComponent();
            this.userName = userName;
            lblLoggedIn.Text = userName;
            lblName.Text = userName;

            PopulateTopics();

            // Show greeting from ChatBot
            AddMessage(_chatBot.GetGreeting(), false);
        }

        private void PopulateTopics()
        {
            var topics = new[] {
                ("☁", "cloud security"), ("⚡", "ddos"), ("🔒", "encryption"), ("❓", "how are you"), ("🪪", "identity theft"),
                ("👤", "insider threat"), ("💻", "iot security"), ("🐛", "malware"), ("🔑", "password"), ("🎣", "phishing"),
                ("👁", "privacy"), ("ℹ", "purpose"), ("💰", "ransomware"), ("🌐", "safe browsing"), ("⚠", "scam"),
                ("📱", "social media"), ("🔗", "supply chain"), ("🛡", "two factor") };

            foreach (var t in topics)
            {
                var b = new Button { Content = t.Item1 + " " + t.Item2, HorizontalContentAlignment = HorizontalAlignment.Left, Padding = new Thickness(12,0,0,0), Height = 30, Background = System.Windows.Media.Brushes.Transparent, BorderThickness = new Thickness(0) };
                b.Click += (_, __) => { txtInput.Text = t.Item2; txtInput.Focus(); };
                TopicList.Children.Add(b);
            }
        }

        private void AddMessage(string text, bool isUser)
        {
            msgCount++;
            lblMsgCount.Text = msgCount.ToString();

            var outer = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0,0,0,10), HorizontalAlignment = isUser ? HorizontalAlignment.Right : HorizontalAlignment.Left };
            if (!isUser)
            {
                var avatar = new Border { Width = 26, Height = 26, Background = System.Windows.Media.Brushes.Black, CornerRadius = new CornerRadius(5) };
                avatar.Child = new TextBlock { Text = "CA", Foreground = System.Windows.Media.Brushes.Green, FontFamily = new System.Windows.Media.FontFamily("Courier New"), FontSize = 10, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                outer.Children.Add(avatar);
                var bubble = new Border { MaxWidth = 360, Background = System.Windows.Media.Brushes.DarkGreen, BorderBrush = System.Windows.Media.Brushes.Green, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(3,8,8,8), Padding = new Thickness(11,7), Margin = new Thickness(8,0,0,0) };
                bubble.Child = new TextBlock { Text = text, Foreground = System.Windows.Media.Brushes.LightGreen, FontSize = 12, TextWrapping = TextWrapping.Wrap };
                outer.Children.Add(bubble);
            }
            else
            {
                var bubble = new Border { MaxWidth = 360, Background = System.Windows.Media.Brushes.DarkOliveGreen, BorderBrush = System.Windows.Media.Brushes.DarkGreen, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8,3,8,8), Padding = new Thickness(11,7), Margin = new Thickness(0,0,8,0) };
                bubble.Child = new TextBlock { Text = text, Foreground = System.Windows.Media.Brushes.LightGreen, FontSize = 12, TextWrapping = TextWrapping.Wrap };
                outer.Children.Add(bubble);
                var avatar = new Border { Width = 26, Height = 26, Background = System.Windows.Media.Brushes.Black, CornerRadius = new CornerRadius(5) };
                avatar.Child = new TextBlock { Text = "You", Foreground = System.Windows.Media.Brushes.LightGreen, FontFamily = new System.Windows.Media.FontFamily("Courier New"), FontSize = 10, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                outer.Children.Add(avatar);
            }

            ChatPanel.Children.Add(outer);
            ChatScrollViewer.ScrollToBottom();
        }

        private void BtnSend_Click(object sender, RoutedEventArgs e)
        {
            var text = txtInput.Text?.Trim();
            if (string.IsNullOrWhiteSpace(text)) return;
            AddMessage(text, true);
            txtInput.Clear();

            var reply = handler.GetResponse(text, userName);
            // update topic labels if detected
            var detected = DetectKeyword(text);
            if (!string.IsNullOrWhiteSpace(detected))
            {
                lblLastTopic.Text = detected;
                if (string.IsNullOrWhiteSpace(lblFavTopic.Text) || lblFavTopic.Text == "-") { lblFavTopic.Text = detected; topicCount++; lblTopicCount.Text = topicCount.ToString(); }
            }

            // detect sentiment and update
            var sent = DetectSentiment(text);
            UpdateSentimentUI(sent);

            AddMessage(reply, false);
        }

        private string DetectKeyword(string input)
        {
            var s = input.ToLowerInvariant();
            if (s.Contains("phishing")) return "phishing";
            if (s.Contains("password")) return "password";
            if (s.Contains("malware")) return "malware";
            if (s.Contains("encryption")) return "encryption";
            if (s.Contains("privacy")) return "privacy";
            if (s.Contains("ransomware")) return "ransomware";
            if (s.Contains("scam")) return "scam";
            if (s.Contains("two factor") || s.Contains("2fa")) return "two factor";
            if (s.Contains("ddos")) return "ddos";
            if (s.Contains("safe browsing")) return "safe browsing";
            return string.Empty;
        }

        private string DetectSentiment(string input)
        {
            var s = input.ToLowerInvariant();
            if (s.Contains("worried") || s.Contains("scared") || s.Contains("afraid") || s.Contains("concerned")) return "Worried";
            if (s.Contains("curious") || s.Contains("interested") || s.Contains("want to know") || s.Contains("how does") || s.Contains("what is")) return "Curious";
            if (s.Contains("frustrated") || s.Contains("confused") || s.Contains("don't understand") || s.Contains("too much") || s.Contains("complicated")) return "Frustrated";
            if (s.Contains("confident") || s.Contains("understand") || s.Contains("got it") || s.Contains("makes sense")) return "Confident";
            return "Neutral";
        }

        private void UpdateSentimentUI(string sentiment)
        {
            switch (sentiment)
            {
                case "Worried": lblSentimentIcon.Text = "😟"; lblSentiment.Text = "Worried"; break;
                case "Curious": lblSentimentIcon.Text = "🤔"; lblSentiment.Text = "Curious"; break;
                case "Frustrated": lblSentimentIcon.Text = "😤"; lblSentiment.Text = "Frustrated"; break;
                case "Confident": lblSentimentIcon.Text = "😊"; lblSentiment.Text = "Confident"; break;
                default: lblSentimentIcon.Text = "😐"; lblSentiment.Text = "Neutral"; break;
            }
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ChatPanel.Children.Clear();
            msgCount = 0; lblMsgCount.Text = "0";
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}