using System.Windows;

namespace CyberAware.UI.Wpf
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            var nameDialog = new NameEntryWindow();
            bool? result = nameDialog.ShowDialog();
            if (result == true)
            {
                var mainWindow = new MainWindow(nameDialog.EnteredName);
                mainWindow.Show();
            }
            else
            {
                Shutdown();
            }
        }
    }
}