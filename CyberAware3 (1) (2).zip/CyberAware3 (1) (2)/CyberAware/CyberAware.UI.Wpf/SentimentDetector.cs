using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberAware.UI.Wpf
{
    public enum Sentiment { Neutral, Worried, Curious, Frustrated, Happy }

    public class SentimentDetector
    {
        private readonly Dictionary<Sentiment, List<string>> _triggers = new();

        public SentimentDetector()
        {
            _triggers[Sentiment.Worried] = new List<string> { "worried", "scared", "afraid", "anxious", "nervous", "unsafe" };
            _triggers[Sentiment.Curious] = new List<string> { "curious", "wonder", "interested", "want to know", "how does", "what is", "tell me" };
            _triggers[Sentiment.Frustrated] = new List<string> { "frustrated", "confused", "don't understand", "too much", "complicated", "i give up" };
            _triggers[Sentiment.Happy] = new List<string> { "great", "thanks", "helpful", "awesome", "love" };
        }

        public Sentiment Detect(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return Sentiment.Neutral;
            var s = input.ToLowerInvariant();
            foreach (var kvp in _triggers)
            {
                foreach (var token in kvp.Value)
                {
                    if (s.Contains(token)) return kvp.Key;
                }
            }
            return Sentiment.Neutral;
        }

        public string GetSentimentOpener(Sentiment s)
        {
            return s switch
            {
                Sentiment.Worried => "I understand that can be worrying — here are some immediate steps to help:",
                Sentiment.Curious => "Great question — here's an interesting note to get you started:",
                Sentiment.Frustrated => "I hear you — let's simplify this to one small step:",
                Sentiment.Happy => "Glad that helped — here's an extra tip:",
                _ => string.Empty,
            };
        }
    }
}