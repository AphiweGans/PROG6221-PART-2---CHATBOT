using System;

namespace CyberAware.UI.Wpf
{
    public class ChatMessage
    {
        public enum SenderType { Bot, User }
        public SenderType Sender { get; set; }
        public string Text { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }
}