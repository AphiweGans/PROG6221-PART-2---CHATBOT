using System;

namespace CyberAware.UI.Wpf
{
    public class ChatBot
    {
        private readonly KeywordResponder _keywords = new();
        private readonly SentimentDetector _sentiment = new();
        private readonly MemoryStore _memory = new();
        private bool _awaitingName = true;
        private string? _lastTopic;

        public ChatBot()
        {
        }

        public string GetGreeting()
        {
            return "Welcome to CyberAware — I can help you with passwords, phishing, scams, privacy and more. What's your name?";
        }

        public string ProcessInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return string.Empty;
            input = input.Trim();

            // 1: capture name if awaiting
            if (_awaitingName)
            {
                // simple extraction: take first token as name
                var name = input.Split(' ', ',', '.')[0];
                _memory.UserName = name;
                _awaitingName = false;
                return $"Nice to meet you, {name}! Tell me a topic you're interested in (e.g., privacy, phishing, passwords).";
            }

            // 2: follow-up checks
            var lowered = input.ToLowerInvariant();
            if (lowered.Contains("tell me more") || lowered.Contains("explain more") || lowered == "more")
            {
                if (!string.IsNullOrWhiteSpace(_lastTopic))
                {
                    var resp = _keywords.GetResponse(_lastTopic) ?? "I don't have more on that right now.";
                    return resp;
                }
            }

            // 3: sentiment
            var s = _sentiment.Detect(input);
            var opener = _sentiment.GetSentimentOpener(s);

            // 4: keyword detection
            var kwResp = _keywords.GetResponse(input);
            if (!string.IsNullOrWhiteSpace(kwResp))
            {
                _lastTopic = kwResp.Contains(' ') ? kwResp.Split(' ')[0] : kwResp; // not ideal but track something
                // attempt to store favourite if user said 'i like' or 'my favourite'
                if (lowered.Contains("i like ") || lowered.Contains("my favourite") || lowered.Contains("my favorite"))
                {
                    foreach (var k in _keywords.GetAllKeywords())
                    {
                        if (lowered.Contains(k)) { _memory.FavouriteTopic = k; break; }
                    }
                }
                return (string.IsNullOrWhiteSpace(opener) ? "" : opener + " ") + kwResp;
            }

            // 5: special phrases
            if (lowered.Contains("how are you")) return "I'm doing well — thanks for asking!";
            if (lowered.Contains("what can you do") || lowered.Contains("what can i ask"))
            {
                return "You can ask me about phishing, passwords, malware, privacy, ransomware, ddos and more.";
            }

            // 6: fallback
            var fallbacks = new[] { "I didn't recognise that topic. Try selecting one from the Topics list, or ask about phishing, malware, passwords, encryption, or privacy.", "Sorry, I couldn't understand that — try asking about passwords or phishing.", "I can help with passwords, phishing, malware, encryption, and privacy. Which would you like to discuss?" };
            var r = new Random();
            return fallbacks[r.Next(fallbacks.Length)];
        }
    }
}