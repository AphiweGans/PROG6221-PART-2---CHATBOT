# Copilot Instructions

## Project Guidelines
- User prefers no code changes during process and requires startup sequence: blank -> audio -> name prompt -> main UI